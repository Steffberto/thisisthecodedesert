package com.pq.apprenticeship.de;

public class MainMIGI {

	public static void main(String[] args) {
		Controllcenter executeproblem = new Controllcenter();
		executeproblem.shapes();
	}

}
