
public class Rechteck {
	 private String nameRechteck = "Rechteck";
	 private static String farbeRechteck;
	 
	 public static double l�ngeRechteck;
	 public static double breiteRechteck;
	 public static double fl�cheRechteck;
	 public static int zufallfarbeRechteck;
	 public static void randomRechteck()
	 {
		 l�ngeRechteck = (double)((Math.random()) * 10 + 1);
		 breiteRechteck = (double)((Math.random()) * 10 + 1);
		 
		 fl�cheRechteck = l�ngeRechteck * breiteRechteck;
		 
		 zufallfarbeRechteck = (int)((Math.random()) * 4 + 1);
		 int zufallfarbeintRechteck = zufallfarbeRechteck;
		 if(zufallfarbeintRechteck == 1)
		 {
			 farbeRechteck = "rot";
		 }
		 else if(zufallfarbeintRechteck == 2)
		 {
			 farbeRechteck = "gr�n";
		 }
		 else if(zufallfarbeintRechteck == 3)
		 {
			 farbeRechteck = "blau";
		 }
		 else
		 {
			 farbeRechteck = "gelb";
		 }
		 
	 }
}
