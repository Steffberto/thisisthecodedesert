
public class Kreis {
	 private String nameKreis = "Kreis";
	 private static String farbeKreis;
	 
	 public static double durchmesserKreis;
	 public static double radiusKreis;
	 public static double fl�cheKreis;
	 public static int zufallfarbeKreis;
	 public static void randomRechteck()
	 {
		 durchmesserKreis = (double)((Math.random()) * 10 + 1);
		 radiusKreis = durchmesserKreis / 2;
		 
		 fl�cheKreis = radiusKreis * radiusKreis * Math.PI;
		 
		 zufallfarbeKreis = (int)((Math.random()) * 4 + 1);
		 int zufallfarbeintRechteck = zufallfarbeKreis;
		 if(zufallfarbeintRechteck == 1)
		 {
			 farbeKreis = "rot";
		 }
		 else if(zufallfarbeintRechteck == 2)
		 {
			 farbeKreis = "gr�n";
		 }
		 else if(zufallfarbeintRechteck == 3)
		 {
			 farbeKreis = "blau";
		 }
		 else
		 {
			 farbeKreis = "gelb";
		 }
		 
	 }
}
