
public class View {

public static void ausgaben() {
	int anzahlRandom;
	int anzahldersteineQuadrat = 0;
	int anzahldersteineRechteck = 0;
	int anzahldersteineKreis = 0;
	int anzahldersteineDreieck = 0;
	
	String typendersteineQuadrat = "Quadrat/e";
	String typendersteineRechteck = "Rechteck/e";
	String typendersteineKreis = "Kreis/e";
	String typendersteineDreieck = "Dreieck/e";
	
	String farberot = "rot/e";
	String farbegr�n = "gr�n/e";
	String farbeblau = "blau/e";
	String farbegelb = "gelb/e";
	
	
	
	System.out.println("Willkommen beim Mosaik-Generator. Ein Mosaik wird jetzt erstellt.");
	System.out.println("Es gibt" + " " + anzahldersteineQuadrat + " " + farberot + " " + typendersteineQuadrat);
	System.out.println("Es gibt" + " " + anzahldersteineQuadrat + " " + farbegr�n + " " + typendersteineQuadrat);
	System.out.println("Es gibt" + " " + anzahldersteineQuadrat + " " + farbeblau + " " + typendersteineQuadrat);
	System.out.println("Es gibt" + " " + anzahldersteineQuadrat + " " + farbegelb + " " + typendersteineQuadrat);
	System.out.println("Es gibt" + " " + anzahldersteineRechteck + " " + farberot + " " + typendersteineRechteck);
	System.out.println("Es gibt" + " " + anzahldersteineRechteck + " " + farbegr�n + " " + typendersteineRechteck);
	System.out.println("Es gibt" + " " + anzahldersteineRechteck + " " + farbeblau + " " + typendersteineRechteck);
	System.out.println("Es gibt" + " " + anzahldersteineRechteck + " " + farbegelb + " " + typendersteineRechteck);
	System.out.println("Es gibt" + " " + anzahldersteineKreis + " " + farberot + " " + typendersteineKreis);
	System.out.println("Es gibt" + " " + anzahldersteineKreis + " " + farbegr�n + " " + typendersteineKreis);
	System.out.println("Es gibt" + " " + anzahldersteineKreis + " " + farbeblau + " " + typendersteineKreis);
	System.out.println("Es gibt" + " " + anzahldersteineKreis + " " + farbegelb + " " + typendersteineKreis);
	System.out.println("Es gibt" + " " + anzahldersteineDreieck + " " + farberot + " " + typendersteineDreieck);
	System.out.println("Es gibt" + " " + anzahldersteineDreieck + " " + farbegr�n + " " + typendersteineDreieck);
	System.out.println("Es gibt" + " " + anzahldersteineDreieck + " " + farbeblau + " " + typendersteineDreieck);
	System.out.println("Es gibt" + " " + anzahldersteineDreieck + " " + farbegelb + " " + typendersteineDreieck);
}
public static void randomObjekte()
{
	for(int random = 0; random < 50; random++)
	{
	Quadrat rQuadrat = new Quadrat();
	int randompc = (int)((Math.random()) * 100 + 1);
	random = randompc;
	if(randompc > 50)
	{
	System.out.println(randompc);
	}
	}	
	for(int random1 = 0; random1 < 50; random1++)
	{
	Rechteck rRechteck = new Rechteck();
	int randompc1 = (int)((Math.random()) * 100 + 1);
	random1 = randompc1;
	}
	for(int random2 = 0; random2 < 50; random2++)
	{
	Kreis rKreis = new Kreis();
	int randompc2 = (int)((Math.random()) * 100 + 1);
	random2 = randompc2;
	}
	for(int random3 = 0; random3 < 50; random3++)
	{
	Dreieck rDreieck = new Dreieck();
	int randompc3 = (int)((Math.random()) * 100 + 1);
	random3 = randompc3;
	}	
	
}
 
}
