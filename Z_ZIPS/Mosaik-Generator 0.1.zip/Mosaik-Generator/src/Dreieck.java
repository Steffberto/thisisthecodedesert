
public class Dreieck {
	 private String nameDreieck = "Kreis";
	 private static String farbeDreieck;
	 
	 public static double dreieckbreite;
	 public static double dreieckh�he;
	 
	 public static double fl�chedreieck;
	 public static int zufallfarbeDreieck;
	 public static void randomRechteck()
	 {
		 dreieckbreite = (double)((Math.random()) * 10 + 1);
		 dreieckh�he = (double)((Math.random()) * 10 + 1);
		 
		 fl�chedreieck = 0.5 * dreieckbreite * dreieckh�he;
		 
		 zufallfarbeDreieck = (int)((Math.random()) * 4 + 1);
		 int zufallfarbeintRechteck = zufallfarbeDreieck;
		 if(zufallfarbeintRechteck == 1)
		 {
			 farbeDreieck = "rot";
		 }
		 else if(zufallfarbeintRechteck == 2)
		 {
			 farbeDreieck = "gr�n";
		 }
		 else if(zufallfarbeintRechteck == 3)
		 {
			 farbeDreieck = "blau";
		 }
		 else
		 {
			 farbeDreieck = "gelb";
		 }
		 
	 }
}
