
public class Quadrat {
 private String nameQuadrat = "Quadrat";
 private static String farbeQuadrat;
 
 public static double l�ngeQuadrat;
 public static double breiteQuadrat;
 public static double fl�cheQuadrat;
 public static int zufallfarbeQuadrat;
 
 public static void randomQuadrat()
 {
	 l�ngeQuadrat = (double)((Math.random()) * 10 + 1);
	 breiteQuadrat = (double)((Math.random()) * 10 + 1);
	 
	 fl�cheQuadrat = l�ngeQuadrat * breiteQuadrat;
	 
	 zufallfarbeQuadrat = (int)((Math.random()) * 4 + 1);
	 int zufallfarbeintQuadrat = zufallfarbeQuadrat;
	 if(zufallfarbeintQuadrat == 1)
	 {
		 farbeQuadrat = "rot";
	 }
	 else if(zufallfarbeintQuadrat == 2)
	 {
		 farbeQuadrat = "gr�n";
	 }
	 else if(zufallfarbeintQuadrat == 3)
	 {
		 farbeQuadrat = "blau";
	 }
	 else
	 {
		 farbeQuadrat = "gelb";
	 }
	 
 }
}
