
public class Mainmosaik {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		View.ausgaben();
		View.randomObjekte();
	}

}
